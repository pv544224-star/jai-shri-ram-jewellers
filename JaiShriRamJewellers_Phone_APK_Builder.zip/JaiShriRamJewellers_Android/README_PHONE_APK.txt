PHONE-ONLY APK METHOD (FREE)

1. Download this ZIP to your phone and extract it.
2. Open GitHub in Chrome and create a free account/login.
3. Create a NEW PUBLIC repository, e.g. jai-shri-ram-jewellers.
4. Upload ALL files/folders from this project into the repository.
5. Open the repository > Actions.
6. Select “Build Jai Shri Ram Jewellers APK”.
7. Tap “Run workflow”.
8. Wait for the build to finish with a green check.
9. Open the completed workflow run and download the artifact named:
   Jai-Shri-Ram-Jewellers-APK
10. Extract the downloaded artifact and install app-debug.apk on your Android phone.

This project already contains the GitHub Actions workflow needed to build the APK.
