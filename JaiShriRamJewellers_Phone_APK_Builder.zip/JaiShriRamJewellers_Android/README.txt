JAI SHRI RAM JEWELLERS - ANDROID PROJECT

This is a ready Android Studio project wrapping the free offline jewellery web app in a real Android app.

To create the APK:
1. Install Android Studio on a computer.
2. Open this project folder.
3. Let Gradle sync.
4. Select Build > Build App Bundle(s) / APK(s) > Build APK(s).
5. Install the generated APK on the Android phone.

The app stores its business data locally on the device. Internet is not required for the core app.
